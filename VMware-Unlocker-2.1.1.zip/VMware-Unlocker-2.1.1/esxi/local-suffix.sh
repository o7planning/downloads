END
logger -t unlocker Starting hostd daemon
/etc/init.d/hostd start
exit 0